package tn.esprit.spring.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import tn.esprit.spring.entity.Equipement;

@Repository
public interface EquipementRepository extends CrudRepository<Equipement, Long> {
}
