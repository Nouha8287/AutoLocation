package tn.esprit.spring.service.tarification;

import org.springframework.stereotype.Component;

/** Tarif longue durée : réduction de 20 %. */
@Component("LONGUE_DUREE")
public class TarificationLongueDuree implements StrategieTarification {

    private static final double REDUCTION = 0.20;

    @Override
    public double calculer(double tarifJournalier, int jours) {
        return tarifJournalier * jours * (1 - REDUCTION);
    }
}
